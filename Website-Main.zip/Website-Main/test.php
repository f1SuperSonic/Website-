<?php
echo 'This message has been sent!'; 

?>